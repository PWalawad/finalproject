import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-customer-with-time-span',
  templateUrl: './all-customer-with-time-span.component.html',
  styleUrls: ['./all-customer-with-time-span.component.css']
})
export class AllCustomerWithTimeSpanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
