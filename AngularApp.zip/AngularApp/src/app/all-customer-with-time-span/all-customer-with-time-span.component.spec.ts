import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllCustomerWithTimeSpanComponent } from './all-customer-with-time-span.component';

describe('AllCustomerWithTimeSpanComponent', () => {
  let component: AllCustomerWithTimeSpanComponent;
  let fixture: ComponentFixture<AllCustomerWithTimeSpanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllCustomerWithTimeSpanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllCustomerWithTimeSpanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
