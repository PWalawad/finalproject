import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user:any={
    name:"",
    email:"",
    password:"",
    consumer_Employee_No:""
    }
   message:any;
   confirmPassword:any;
    constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }
  
    ngOnInit() {
    }
    register()
    {
      console.log(this.confirmPassword);
      console.log(this.user.password);
     if(this.confirmPassword==this.user.password) 
     
     {  
       let observable=this.service.registerme(this.user);
      observable.subscribe((result)=>{
  
        this.user=result;
      
         if(result!=null)
         {
            
                this.router.navigate(['login']);   
         }
         else
         { 
              this.message="kindly visit nearest service center to register";
         }
        });
      }
      else
      {
          this.message="con pass and pass doesnt match"
      }
    }

 

}
