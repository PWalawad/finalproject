import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-displaysearch',
  templateUrl: './displaysearch.component.html',
  styleUrls: ['./displaysearch.component.css']
})
export class DisplaysearchComponent implements OnInit {

  constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }
  mess: any;
bills:any;
no:any;
  ngOnInit() 
  {
    this.route.paramMap.subscribe((record)=>
    {
      
     this.no=record.get("id");
    let observableResult =  this.service.searchbill(this.no);
    observableResult.subscribe((result)=>{
      console.log(result);
      this.bills=result;
      if(result==null)
      {
        this.mess="Kindly Enter Valid Bill No";
      }
    });
  });
  

  }
  // message:any;
  // no:any;
  // bills:any;
  // constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }

  // ngOnInit() 
  // {
 
  //   this.route.paramMap.subscribe((record)=>
  //     {
  //      this.no= record.get("no");  
  //      console.log(this.no);
       
  //      let observableResult =  this.service.searchbill(this.no);
  //     observableResult.subscribe((result)=>{
  //       console.log(result);
   
  //       this.bills=result;
  //       if(this.bills==null)
  //       {
  //         this.message="Enter correct Bill ID";
  //       }
  //     });
  //   });
    
  // }

}
