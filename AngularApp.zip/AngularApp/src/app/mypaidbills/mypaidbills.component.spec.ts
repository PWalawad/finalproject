import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MypaidbillsComponent } from './mypaidbills.component';

describe('MypaidbillsComponent', () => {
  let component: MypaidbillsComponent;
  let fixture: ComponentFixture<MypaidbillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MypaidbillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MypaidbillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
