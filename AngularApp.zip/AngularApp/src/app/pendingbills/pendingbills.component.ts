import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pendingbills',
  templateUrl: './pendingbills.component.html',
  styleUrls: ['./pendingbills.component.css']
})
export class PendingbillsComponent implements OnInit {

  
  bill:any;

  constructor(private service: DataService,private router:Router) { }

  ngOnInit() 
  {
    let observableResult =  this.service.allpendingbills();

    observableResult.subscribe((result)=>{
      console.log(result);
      this.bill = result;
      // this.user=result["bankName"];
      console.log(this.bill);
    });

  }

}
