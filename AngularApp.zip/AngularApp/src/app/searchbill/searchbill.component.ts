import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-searchbill',
  templateUrl: './searchbill.component.html',
  styleUrls: ['./searchbill.component.css']
})
export class SearchbillComponent implements OnInit {
//  bill:any={
// no:""
//  };
no:number;

 constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
  }
// display()
// {
//   this.router.navigate(['displaysearch/'+this.bill.no]);

// }
}
