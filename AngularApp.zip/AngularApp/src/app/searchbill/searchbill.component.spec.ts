import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchbillComponent } from './searchbill.component';

describe('SearchbillComponent', () => {
  let component: SearchbillComponent;
  let fixture: ComponentFixture<SearchbillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchbillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchbillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
