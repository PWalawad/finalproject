import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AboutComponent } from './about/about.component';
import { CONTACTComponent } from './contact/contact.component';
import { DELETEComponent } from './delete/delete.component';
import { NOTFOUNDComponent } from './notfound/notfound.component';
import { RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import {NgModel,NgForm,FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component'
import { AuthService } from './auth.service';
import { ManagerComponent } from './manager/manager.component';
import { CustomerComponent } from './customer/customer.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmergencyComponent } from './emergency/emergency.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { PerticularcustomerdetailsComponent } from './perticularcustomerdetails/perticularcustomerdetails.component';
import { DuedateexpirecustomerlistComponent } from './duedateexpirecustomerlist/duedateexpirecustomerlist.component';
import { AllCustomerWithTimeSpanComponent } from './all-customer-with-time-span/all-customer-with-time-span.component';

import { DefaultcustomerlistComponent } from './defaultcustomerlist/defaultcustomerlist.component';
import { EmployeeselecteddefaultcustomerComponent } from './employeeselecteddefaultcustomer/employeeselecteddefaultcustomer.component';
import { AddnextmonthbillComponent } from './addnextmonthbill/addnextmonthbill.component';
import { AllbilllistComponent } from './allbilllist/allbilllist.component';
import { PendingbillsComponent } from './pendingbills/pendingbills.component';
import { PaidbillsComponent } from './paidbills/paidbills.component';
import { MybillComponent } from './mybill/mybill.component';
import { MypaidbillsComponent } from './mypaidbills/mypaidbills.component';
import { MypendingbillsComponent } from './mypendingbills/mypendingbills.component';
import { SearchbillComponent } from './searchbill/searchbill.component';
import { DisplaysearchComponent } from './displaysearch/displaysearch.component';
import { EditaddressComponent } from './editaddress/editaddress.component';
import { EditbankComponent } from './editbank/editbank.component';
import { PaymybillComponent } from './paymybill/paymybill.component';
import { ConfirmpaymentComponent } from './confirmpayment/confirmpayment.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    CONTACTComponent,
    DELETEComponent,
    NOTFOUNDComponent,
    RegisterComponent,
    EmergencyComponent,
    LoginComponent,
    ManagerComponent,
    CustomerComponent,
    EmployeeComponent,
    EmergencyComponent,
    CustomerlistComponent,
    PerticularcustomerdetailsComponent,
    DuedateexpirecustomerlistComponent,
    AllCustomerWithTimeSpanComponent,
    
    DefaultcustomerlistComponent,
    EmployeeselecteddefaultcustomerComponent,
    AddnextmonthbillComponent,
    AllbilllistComponent,
    PendingbillsComponent,
    PaidbillsComponent,
    MybillComponent,
    MypaidbillsComponent,
    MypendingbillsComponent,
    SearchbillComponent,
    DisplaysearchComponent,
    EditaddressComponent,
    EditbankComponent,
    PaymybillComponent,
    ConfirmpaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:"",component:HomeComponent},
      {path:"home",component:HomeComponent},
      {path:"about",component:AboutComponent},
      {path:"contact",component:CONTACTComponent},
      {path:"register",component:RegisterComponent},
      {path:"delete/:id",component:DELETEComponent},
      {path:"login",component:LoginComponent},
      {path:"manager",component:ManagerComponent},
      {path:"employee",component:EmployeeComponent,canActivate:[AuthService]},
      {path:"customer/:id",component:CustomerComponent},
      {path:"customerlist",component:CustomerlistComponent},
      {path:"perticularcustomerdetails/:id",component:PerticularcustomerdetailsComponent},
      {path:"duedateexpirecustomerlist",component:DuedateexpirecustomerlistComponent},
      {path:"emergency", component:EmergencyComponent},
      {path:"AllCustomerWithTimeSpanComponent", component:AllCustomerWithTimeSpanComponent},
      {path:"defaultcustomerlist", component:DefaultcustomerlistComponent},
      {path:"employeeselecteddefaultcustomer", component:EmployeeselecteddefaultcustomerComponent},
      {path:"addnextmonthbill/:id", component:AddnextmonthbillComponent},
      {path:"allbilllist", component:AllbilllistComponent},
      {path:"pendingbills", component:PendingbillsComponent},
      {path:"paidbills", component:PaidbillsComponent},
      {path:"mybill/:id", component:MybillComponent},
      {path:"mypaidbills/:id", component:MypaidbillsComponent},
      {path:"mypendingbills/:id", component:MypendingbillsComponent},
      {path:"searchbill", component:SearchbillComponent},
      {path:"displaysearch/:id", component:DisplaysearchComponent},
      {path:"editaddress/:id",component:EditaddressComponent},
      {path:"editbank/:id", component:EditbankComponent},
      {path:"paymybill/:id", component:PaymybillComponent},
      {path:"confirmpayment/:id", component:ConfirmpaymentComponent},
      {path:"**",component:NOTFOUNDComponent}
    
      
    ])
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
