import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MypendingbillsComponent } from './mypendingbills.component';

describe('MypendingbillsComponent', () => {
  let component: MypendingbillsComponent;
  let fixture: ComponentFixture<MypendingbillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MypendingbillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MypendingbillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
