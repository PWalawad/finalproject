import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmpayment',
  templateUrl: './confirmpayment.component.html',
  styleUrls: ['./confirmpayment.component.css']
})
export class ConfirmpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
