import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-editaddress',
  templateUrl: './editaddress.component.html',
  styleUrls: ['./editaddress.component.css']
})
export class EditaddressComponent implements OnInit {
  add:any={
  "city":"",
  "state":""
}
user:any;
no:any;
  constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }
  ngOnInit() {
  }
  addaddress()
    {
      this.route.paramMap.subscribe((record)=>
    {
      
     this.no=record.get("id");
     let observableResult =  this.service.addaddress(this.no,this.add);
    observableResult.subscribe((result)=>{
    
      this.user=result;
      if(result!=null)
      {
         
             this.router.navigate(['customer/'+this.user.id]);   
      }
    });
  });
  
  }
}