import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymybillComponent } from './paymybill.component';

describe('PaymybillComponent', () => {
  let component: PaymybillComponent;
  let fixture: ComponentFixture<PaymybillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymybillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymybillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
