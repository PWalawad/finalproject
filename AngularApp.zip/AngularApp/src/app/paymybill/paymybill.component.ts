import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-paymybill',
  templateUrl: './paymybill.component.html',
  styleUrls: ['./paymybill.component.css']
})
export class PaymybillComponent implements OnInit {
 no:any;
 bill:any={
   amount:""
 }

  constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() 
  {
    this.route.paramMap.subscribe((record)=>
    {
      console.log(record);
     this.no=record.get("id");
     
     let observableResult =  this.service.paymybill(this.no);
  
    observableResult.subscribe((result)=>{
    
      this.bill=result;
     
    });
  });
  }
  goto()
  {
    this.router.navigate(['confirmpayment/'+this.no]);
  }
}
