import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }

  customer:any;
  
  id:any;
  
    ngOnInit() 
    {
      this.route.paramMap.subscribe((record)=>
      {
       this.id= record.get("id");
      let observableResult =  this.service.myprofile(this.id);
      observableResult.subscribe((result)=>{
        console.log(result);
        this.customer=result;
      });
    });
  }


}
