import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-editbank',
  templateUrl: './editbank.component.html',
  styleUrls: ['./editbank.component.css']
})
export class EditbankComponent implements OnInit {
  bank:any={
    "bankName":"",
    "AccountNo":""
  }
  user:any;
  no:any;
    constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }
    ngOnInit() {
    }
    addbankdetails()
      {
        this.route.paramMap.subscribe((record)=>
      {
        
       this.no=record.get("id");
       
       let observableResult =  this.service.addbankdetails(this.no,this.bank);
      observableResult.subscribe((result)=>{
      
        this.user=result;
        if(result!=null)
        {
           
               this.router.navigate(['customer/'+this.user.id]);   
        }
      });
    });
    
    }
}
