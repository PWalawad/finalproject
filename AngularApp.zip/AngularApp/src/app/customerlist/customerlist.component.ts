import { Component, OnInit } from '@angular/core';
import {DataService} from '../data.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {

  user:any;

  constructor(private service: DataService,private router:Router) { }

  ngOnInit() 
  {
    let observableResult =  this.service.dispayAllCustomer();

    observableResult.subscribe((result)=>{
      console.log(result);
      this.user = result;
      // this.user=result["bankName"];
      console.log(this.user);
    });

  }

  view(id)
  {
    this.router.navigate(['perticularcustomerdetails/'+id]);  
  }

}
