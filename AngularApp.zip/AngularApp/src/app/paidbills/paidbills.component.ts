import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-paidbills',
  templateUrl: './paidbills.component.html',
  styleUrls: ['./paidbills.component.css']
})
export class PaidbillsComponent implements OnInit {

  bill:any;

  constructor(private service: DataService,private router:Router) { }

  ngOnInit() 
  {
    let observableResult =  this.service.paidbills();

    observableResult.subscribe((result)=>{
      console.log(result);
      this.bill = result;
      // this.user=result["bankName"];
      console.log(this.bill);
    });

  }
}
