import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService
implements CanActivate 
{
  constructor(private router:Router) { }
  canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot)
  {
    if(this.isloggedin())
    {
      return true;
    }
    else
    {
      this.router.navigate(['login']);
      return false;
    }
  }
  isloggedin()
  {
      if(window.sessionStorage.getItem("isloggedin")!=null 
      &&
       window.sessionStorage.getItem("isloggedin")=="1")
      {
        return true;
      }
      else
      {
        false;
      }
  
    }
    CheckUser(user)
    {
      
        if (user!=null)
        {
          window.sessionStorage.setItem("isloggedin","1");
          return true;
        }
        else{
          return false; 
        }
    }
    SignOut()
    {
      window.sessionStorage.setItem("isloggedin","0");
    }
}

