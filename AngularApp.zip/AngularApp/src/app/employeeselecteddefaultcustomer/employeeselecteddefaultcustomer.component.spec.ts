import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeselecteddefaultcustomerComponent } from './employeeselecteddefaultcustomer.component';

describe('EmployeeselecteddefaultcustomerComponent', () => {
  let component: EmployeeselecteddefaultcustomerComponent;
  let fixture: ComponentFixture<EmployeeselecteddefaultcustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeselecteddefaultcustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeselecteddefaultcustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
