import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-addnextmonthbill',
  templateUrl: './addnextmonthbill.component.html',
  styleUrls: ['./addnextmonthbill.component.css']
})
export class AddnextmonthbillComponent implements OnInit {

  bill:any={
  amount:"",
  startDate:"",
  endDate:"",
  dueDatw:"",
  status:""
  }
  Bills:any;
  message:any;
  constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
  }
  addbill()
  {
    
    this.route.paramMap.subscribe((record)=>
    {
     let id= record.get("id");
     let observable=this.service.addnextmonthbill(id,this.bill);
    observable.subscribe((result)=>{

      this.Bills=result;
    
       if(result!=null)
       {
              this.message="Bill Added Successfully...!!!"
              this.router.navigate(['customerlist']);   
       }
       else
       { 
            this.message="Error";
       }
      });


    });
  }
}

