import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddnextmonthbillComponent } from './addnextmonthbill.component';

describe('AddnextmonthbillComponent', () => {
  let component: AddnextmonthbillComponent;
  let fixture: ComponentFixture<AddnextmonthbillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddnextmonthbillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddnextmonthbillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
