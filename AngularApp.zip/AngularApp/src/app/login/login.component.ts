import { Component, OnInit } from '@angular/core';
import {AuthService}  from  '../auth.service'
import { Router } from '@angular/router';
import { DataService } from '../data.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   userdetails=
  {
  id:"",
  accountNo:"",
  bankName:"",
  email:"",
  name:"",
  user_type:"",
  password:"",
  consumer_Employee_No:""
}
message:any;
  user:any;

  constructor(private service: DataService,private authService:AuthService,private router:Router) { }

  ngOnInit() {
  }
 SignIn()
 {
   
   let observable=this.service.login(this.userdetails);
    observable.subscribe((result)=>{

      this.user=result;
      
        console.log("inside log in");
       
       let isinvalid=this.authService.CheckUser(this.user);
       if(result!=null)
       {
         ///this.authService.setSession(result)
         
         if(this.user.roll=="customer")
            { 
              this.router.navigate(['customer/'+this.user.id]);
             
            }
         else if(this.user.roll=="employee")
           {
               this.router.navigate(['employee']);
           }
         else
         {
             this.router.navigate(['manager']);
             
         }
       }
       else
       {
         this.message="Username or password is incorrect";
       } 
     })
 }

  Home()
  {
      this.router.navigate(['home']);  
    
  }

}
