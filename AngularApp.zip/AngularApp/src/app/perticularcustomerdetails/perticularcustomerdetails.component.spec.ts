import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerticularcustomerdetailsComponent } from './perticularcustomerdetails.component';

describe('PerticularcustomerdetailsComponent', () => {
  let component: PerticularcustomerdetailsComponent;
  let fixture: ComponentFixture<PerticularcustomerdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerticularcustomerdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerticularcustomerdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
