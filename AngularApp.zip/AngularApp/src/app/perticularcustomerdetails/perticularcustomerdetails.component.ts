import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-perticularcustomerdetails',
  templateUrl: './perticularcustomerdetails.component.html',
  styleUrls: ['./perticularcustomerdetails.component.css']
})
export class PerticularcustomerdetailsComponent implements OnInit {

constructor(private service: DataService,private router:Router,private route:ActivatedRoute) { }

customer:any;
bill:any;
id:any;
  ngOnInit() 
  {
    this.route.paramMap.subscribe((record)=>
    {
     this.id= record.get("id");
    let observableResult =  this.service.singleCustomerDetails(this.id);
    observableResult.subscribe((result)=>{
      console.log(result);
      this.customer=result;
    });
  });
  
  this.route.paramMap.subscribe((record)=>
  {
   this.id= record.get("id");
  let observableResult =  this.service.singleCustomerBillDetails(this.id);
  observableResult.subscribe((result)=>{
    console.log(result);
    this.bill=result;
  });
  });
  }


}
