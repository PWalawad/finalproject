import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllbilllistComponent } from './allbilllist.component';

describe('AllbilllistComponent', () => {
  let component: AllbilllistComponent;
  let fixture: ComponentFixture<AllbilllistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllbilllistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllbilllistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
