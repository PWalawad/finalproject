import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allbilllist',
  templateUrl: './allbilllist.component.html',
  styleUrls: ['./allbilllist.component.css']
})
export class AllbilllistComponent implements OnInit {

  bill:any;

  constructor(private service: DataService,private router:Router) { }

  ngOnInit() 
  {
    let observableResult =  this.service.allbills();

    observableResult.subscribe((result)=>{
      console.log(result);
      this.bill = result;
      // this.user=result["bankName"];
      console.log(this.bill);
    });

  }
}
