import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(public http:HttpClient) { }

  login(user)
  {
    console.log("inside log in");
    return this.http.post("http://localhost:8080/day13.4_REST_SRVR/home/login",user);
  }
  singleCustomerDetails(id)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/employee/"+id);
  }
  deleteCustomer(id)
  {
    return this.http.delete("http://localhost:8080/day13.4_REST_SRVR/employee/delete/"+id);
  }
  dispayAllCustomer()
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/employee/customers")
  }
  dueDateExpireCustomerList(startDate1)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/employee/default/"+startDate1);
  }
  singleCustomerBillDetails(id)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/employee/allbills/"+id);
  }
  addnextmonthbill(id,bill)
  {

    return this.http.post("http://localhost:8080/day13.4_REST_SRVR/employee/"+id, bill);
  }
  allbills()
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/employee/allbills");
  }
  allpendingbills()
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/employee/allpendingbills");
  }
  paidbills()
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/employee/allpaidbills");
  }
  registerme(user)
  {
    return this.http.post("http://localhost:8080/day13.4_REST_SRVR/home/register",user);
  }
  mybills(id)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/customer/mybills"+id);
  }
  myprofile(id)
  {
    console.log("inside log in");
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/customer/myprofile/"+id);
  }
  myBillDetails(id)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/customer/mybills/"+id);
  }
  mypaidBillDetails(id)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/customer/mypaidbills/"+id);
  }
  mypendingBillDetails(id)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/customer/mypendingbills/"+id);
  }

  searchbill(no)
  {
    console.log(no);
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/customer/searchbill/"+no);
  }
  addaddress(id,add)
  {
    return this.http.post("http://localhost:8080/day13.4_REST_SRVR/customer/addAddress/"+id, add);
  }
  addbankdetails(id,bank)
  {
    return this.http.post("http://localhost:8080/day13.4_REST_SRVR/customer/addbankdetails/"+id, bank);
  }
  paymybill(id)
  {
    return this.http.get("http://localhost:8080/day13.4_REST_SRVR/customer/paybill/"+id);
  }
}

