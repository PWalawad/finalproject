import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-duedateexpirecustomerlist',
  templateUrl: './duedateexpirecustomerlist.component.html',
  styleUrls: ['./duedateexpirecustomerlist.component.css']
})
export class DuedateexpirecustomerlistComponent implements OnInit {
  Date1 :any={
  startDate1:""
  }; 
  user:any;
  index:any;

  constructor(private service: DataService,private authService:AuthService,private router:Router) { }

  ngOnInit() {
  }
  DateWiseList()
  {
    let observable=this.service.dueDateExpireCustomerList(this.Date1.startDate1);
    observable.subscribe((result)=>{      
              console.log(this.Date1.startDate1);
            
              this.user=result;
              
              console.log(this.user)
              // if(result!=null)
              // {
              //   this.router.navigate(['employeeselecteddefaultcustomer']);
              // }
  });
}
}
