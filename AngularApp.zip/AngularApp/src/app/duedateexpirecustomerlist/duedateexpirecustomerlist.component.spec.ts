import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DuedateexpirecustomerlistComponent } from './duedateexpirecustomerlist.component';

describe('DuedateexpirecustomerlistComponent', () => {
  let component: DuedateexpirecustomerlistComponent;
  let fixture: ComponentFixture<DuedateexpirecustomerlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DuedateexpirecustomerlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DuedateexpirecustomerlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
