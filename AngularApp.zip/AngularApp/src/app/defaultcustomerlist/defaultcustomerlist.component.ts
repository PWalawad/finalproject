import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultcustomerlist',
  templateUrl: './defaultcustomerlist.component.html',
  styleUrls: ['./defaultcustomerlist.component.css']
})
export class DefaultcustomerlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
