import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultcustomerlistComponent } from './defaultcustomerlist.component';

describe('DefaultcustomerlistComponent', () => {
  let component: DefaultcustomerlistComponent;
  let fixture: ComponentFixture<DefaultcustomerlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultcustomerlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultcustomerlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
