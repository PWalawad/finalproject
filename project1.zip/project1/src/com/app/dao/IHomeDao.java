package com.app.dao;

import com.app.pojos.Bill;
import com.app.pojos.User;

public interface IHomeDao 
{
	public User signIn(User u);

	public String logout(User u);

	User registerMeOnline(User newUser);

	public Bill searchBybillNo(Integer id);

	User searchByUserNo(Integer consumer_Employee_No);
  
}
