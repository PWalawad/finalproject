package com.app.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import com.app.pojos.Bill;
import com.app.pojos.User;

@Repository
@Transactional
public class EmployeeDao implements IEmployeeDao {

	@Autowired
	private SessionFactory sf;

	public EmployeeDao() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<User> displayAllCustomers() {
		try{String jpql = "select u from User u where u.roll='customer'";

		return sf.getCurrentSession().createQuery(jpql, User.class).getResultList();}
		catch (Exception e) {
			return null;
		}
	}

	@Override
	public List<User> displayDueDateExpiredCustomers(LocalDate dueDate1) {

		try
			{
				String jpql = "select b from Bill b where b.status='pending' and b.dueDate < :dueDate1";
			List<Bill> user_id = sf.getCurrentSession().createQuery(jpql, Bill.class).setParameter("dueDate1", dueDate1)
					.getResultList();
			List<User> expiredUser = new ArrayList<>();
	
			for (Bill bills : user_id) 
			{
				expiredUser.add(bills.getUserBillDeatils());
			}
			return expiredUser;
	  }
		catch (Exception e) {
			return null;
		}
		
	}
	/*
	 * @Override
	public List<User> displayDueDateExpiredCustomers(LocalDate dueDate) {

		String jpql = "select b from Bill b where b.dueDate < :dueDate";
		List<Bill> user_id = sf.getCurrentSession().createQuery(jpql, Bill.class).setParameter("dueDate", dueDate)
				.getResultList();
		List<User> expiredUser = new ArrayList<>();

		for (Bill bills : user_id) 
		{
			expiredUser.add(bills.getUserBillDeatils());
		}
		return expiredUser;
	}
	 */

	@Override
	public User displaySingleCustomer(int id) {
	
		try{
			String jpql = "select u from User u where u.id=:id";
		
		User u = sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", id).getSingleResult();
		return u;
		}
		catch (Exception e) {
			return null;
		}
	}

	@Override
	public int insertNextMonthBill(User u) {
  System.out.println("inside insertNextbill");
		sf.getCurrentSession().update(u);
		return 1;
	}

	@Override
	public void sendEmailToCustomers() {

	}

	@Override
	public User deleteCustomer(Integer id) {
		try {
			String jpql = "select u from User u where u.id=:id";
			User u = sf.getCurrentSession().createQuery(jpql, User.class).
					setParameter("id", id).getSingleResult();
			sf.getCurrentSession().delete(u);
			return u;
		}
		catch (Exception e) {
			return null;
		}
		
	}
//////////////////////////////////////////////////////
	
	@Override
	public List<Bill> allBills() 
	{
       try 
		{
    	   
    	   String jpql="select b from  Bill b";
		List<Bill> b=sf.getCurrentSession().createQuery(jpql, Bill.class).getResultList();
		return b;
			
		}
		catch (NoResultException nre ) 
		{
	        return null;
			
		}
		
		
	}

	@Override
	public List<Bill> pendingaBills()
	{
try {
     
		String jpql = "select b from Bill b where b.status='pending'";
		List<Bill> bills = sf.getCurrentSession().createQuery(jpql, Bill.class).getResultList();
		//List<Bill> allPendingBills=new ArrayList<>();
		
		
		return bills;
   }
	catch (NoResultException nre ) 
	{
	    return null;
		
	}
}

	@Override
	public List<Bill> paidBills() {
//		try
//		{
			
			String jpql = "select b from Bill b where b.status='paid'";
			//"select u from User u where u.roll='customer'";
			List<Bill> bills = sf.getCurrentSession().createQuery(jpql, Bill.class).getResultList();
			
	
			
			return bills;
//	    }
//		catch (NoResultException nre ) 
//		{
//	        return null;
//			
//		}
	}
	
	
	
}
