package com.app.dao;

import javax.persistence.NoResultException;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.passwordencryption.PasswordUtils;
import com.app.pojos.Bill;
import com.app.pojos.User;
import com.app.pojos.UserType;
import com.app.pojos.offlineDatabaseOfUser;

import sun.security.util.Password;

@Repository
@Transactional
public class HomeDaoIImpl implements IHomeDao
{
	@Autowired
	private SessionFactory sf;

	@Override
	public User signIn(User u) 
	{
		try {
			Integer consumer_Employee_No=u.getConsumer_Employee_No();
			
		
			String jpql="select u from User u where u.consumer_Employee_No =:consumer_Employee_No";
			User findUser=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("consumer_Employee_No", consumer_Employee_No).getSingleResult();
			String saltCode=findUser.getSaltPassword();
			String toVerifypassword=u.getPassword();
			System.out.println(saltCode+""+toVerifypassword);
			String encrPassFromDatabase=PasswordUtils.generateSecurePassword(toVerifypassword, saltCode);
			if(encrPassFromDatabase.equals(findUser.getPassword()))
				return findUser;
			else
				return	null;
			
		}
		catch (NoResultException nre ) {
			
			return null;
			
		}
		
		
	}
	@Override
	public User registerMeOnline(User newUser)
	{
		try {
			Integer consumer_Employee_No=newUser.getConsumer_Employee_No();
			String oldjpql="select o from offlineDatabaseOfUser o where o.consumer_Employee_No =:consumer_Employee_No";
			offlineDatabaseOfUser oldUser=sf.getCurrentSession().createQuery(oldjpql, offlineDatabaseOfUser.class).setParameter("consumer_Employee_No",consumer_Employee_No).getSingleResult();
			System.out.println(oldUser.getConsumer_Employee_No());
			if(oldUser.getConsumer_Employee_No().equals(newUser.getConsumer_Employee_No()))
			{
				newUser.setRoll(UserType.customer);
				String saltCode=PasswordUtils.getSalt(6);
				newUser.setSaltPassword(saltCode);
				System.out.println(saltCode);
				String encyptedPassword=PasswordUtils.generateSecurePassword(newUser.getPassword(), saltCode);
	
				newUser.setPassword(encyptedPassword);
				
				sf.getCurrentSession().persist(newUser);
				System.out.println("rerurning user");
				return newUser;
			}
			else
				return null;
		}
		catch (Exception e) {
			return null;
		}
			
	}

	@Override
	public String logout(User u) {
		try {
			
			Integer consumer_Employee_No =u.getConsumer_Employee_No();
			String jpql="select u from User u where u.consumer_Employee_No =:consumer_Employee_No";
			User findUser=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("consumer_Employee_No", consumer_Employee_No).getSingleResult();
			   return "Logout  successfull"+findUser.getName();
		}
		catch (NoResultException nre ) {
			return "Invalid Login";
		}
		
	}
	@Override
	public Bill searchBybillNo(Integer id)
	{
		
		String jpql="select b from Bill b where b.id = :id";
		try

		{
			Bill paid=sf.getCurrentSession().createQuery(jpql, Bill.class).setParameter("id", id).getSingleResult();
			return paid;
		
		}
		catch (Exception e) {
		  return null;
		}
	}
	@Override
	public User searchByUserNo(Integer consumer_Employee_No)
	{
		
		String jpql="select u from User u where u.consumer_Employee_No = :consumer_Employee_No";
		try

		{
			User paid=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("consumer_Employee_No", consumer_Employee_No).getSingleResult();
			return paid;
		
		}
		catch (Exception e) {
		  return null;
		}
	}

}
