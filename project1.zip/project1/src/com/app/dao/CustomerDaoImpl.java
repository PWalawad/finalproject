package com.app.dao;
import com.app.passwordencryption.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.BillModel;
import com.app.pojos.Address;
import com.app.pojos.Bankdeatils;
import com.app.pojos.Bill;
import com.app.pojos.User;
import com.app.pojos.UserType;
import com.app.pojos.offlineDatabaseOfUser;

@Repository
@Transactional
public class CustomerDaoImpl implements ICustomerDao {

	@Autowired
	private SessionFactory sf;
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<Bill> allBills(Integer id) 
	{
       try 
		{
    	   
    	   String jpql="select u from  User u where u.id = :id ";
		User u=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", id).getSingleResult();
		return u.getBills();
			
		}
		catch (NoResultException nre ) 
		{
	        return null;
			
		}
		
		
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<Bill> myPendingaBills(Integer id)
	{
try {

	 String jpql="select u from  User u where u.id = :id ";
		User u=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", id).getSingleResult();
		 
		List<Bill> allBills=u.getBills();
		List<Bill> pendingBill=new ArrayList<>();
		for (Bill bills : allBills) 
		{
			String Status=bills.getStatus();
			String Status1="pending";
			boolean a=Status.equals(Status1);
			System.out.println(a);
			if(a==true)
			{ pendingBill.add(bills);	
			
			}
		}
		return pendingBill;
   }
	catch (NoResultException nre ) 
	{
	    return null;
		
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public List<Bill> myPaidBills(Integer id) {
		try {

			 String jpql="select u from  User u where u.id = :id ";
				User u=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", id).getSingleResult();
				 
				List<Bill> allBills=u.getBills();
				List<Bill> paidBill=new ArrayList<>();
				for (Bill bills : allBills) 
				{
					String Status=bills.getStatus();
					String Status1="paid";
					boolean a=Status.equals(Status1);
					System.out.println(a);
					if(a==true)
					paidBill.add(bills);	
				}
				return paidBill;
		   }
			catch (NoResultException nre ) 
			{
			    return null;
				
			}
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public User addbankdetails(Bankdeatils b,Integer id) 
	{
		
		try{String jpql="select u from User u where u.id = :id";
		User newUser=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", id).getSingleResult();
		newUser.setBank(b);
		sf.getCurrentSession().update(newUser);
		return newUser;
	}
		catch (NoResultException nre ) 
		{
	        return null;
			
		}
		
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	@Override
	public User forGetPassword(User us)
	{
		Integer consumer_Employee_No=us.getConsumer_Employee_No();
		String email=us.getEmail();
		System.out.println(us.getPassword());
		
		String jpql="select u from User u where u.consumer_Employee_No = :consumer_Employee_No and u.email=:email";
		User newUser=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("consumer_Employee_No", consumer_Employee_No).setParameter("email", email).getSingleResult();
		if(newUser!=null)
		{
			String saltCode=PasswordUtils.getSalt(6);
			newUser.setSaltPassword(saltCode);
			
			String encyptedPassword=PasswordUtils.generateSecurePassword(us.getPassword(), saltCode);
			newUser.setPassword(encyptedPassword);
			
			sf.getCurrentSession().update(newUser);
		}
		return null;
	}
	
	/////////////////////////////////////////////////////////////////////
	@Override
	public User addAddress(Address a, Integer id) 
	{
			try{
				String jpql="select u from User u where u.id = :id";
			User newUser=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", id).getSingleResult();
			newUser.addAddress(a);
			sf.getCurrentSession().update(newUser);
			return newUser;
			
		}
		catch (NoResultException nre ) 
		{
	        return null;
			
		}
		
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////
	@Override
	public Bill paybill(Integer id)
	{
		String jpql="select b from Bill b where b.id = :id";
		//BillModel bm=new BillModel();
		
		try
		{
			Bill unPaid=sf.getCurrentSession().createQuery(jpql, Bill.class).setParameter("id", id).getSingleResult();
			Integer status=unPaid.getDueDate().compareTo(LocalDate.now()); 
		    	
				if(status<0)
		       {	
					unPaid.setPaymentDoneDate(LocalDate.now());
					unPaid.setAmount(unPaid.getAmount()+10);	
					unPaid.setStatus("paid");
					sf.getCurrentSession().update(unPaid);
					return unPaid;
		       }
		       else
		       {
		    	  
		    		unPaid.setPaymentDoneDate(LocalDate.now());
		    	    unPaid.setStatus("paid");
					sf.getCurrentSession().update(unPaid); 
		    	   return unPaid;
		       }
		
					 
		}
		catch(NoResultException nre)
		{
			return null;
		}
			
	
	}
	@Override
	public User myProfile(Integer id)
	{
		String jpql="select u from User u where u.id = :id";
		User newUser=sf.getCurrentSession().createQuery(jpql, User.class).setParameter("id", id).getSingleResult();
		
		return newUser;
	}
	@Override
	public Bill searchBill(Integer id) {
		try{String jpql="select b from Bill b where b.id = :id";
		Bill b=sf.getCurrentSession().createQuery(jpql, Bill.class).setParameter("id", id).getSingleResult();
		return b;
		}
		catch (Exception e) {
			return null;
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
