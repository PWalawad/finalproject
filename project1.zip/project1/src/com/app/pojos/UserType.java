package com.app.pojos;

public enum UserType
{
   customer,employee,manager
}
