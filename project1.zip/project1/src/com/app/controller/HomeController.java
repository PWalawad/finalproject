package com.app.controller;

import java.io.UnsupportedEncodingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.app.dao.IHomeDao;
import com.app.pojos.Bill;
import com.app.pojos.User;


@CrossOrigin
@RestController
@RequestMapping("/home")
public class HomeController 
{
	 @Autowired 
	    private IHomeDao dao;
	 
	 @PostMapping("/login")
	 public User logIn(@RequestBody User u)
	 {
		User findUser=dao.signIn(u) ;
		return findUser;	 
	 }
	 @PostMapping("/register")
		public User registerMeOnline(@RequestBody User b) throws UnsupportedEncodingException
		{
			
			//user.setPassword(passwordEncoder.encode(accountDto.getPassword()));
			User u=dao.registerMeOnline(b);
			return u;
			
		}
	 @GetMapping("/searchbybillno/{id}")
	 public Bill searchBybillNo(@PathVariable ("id") Integer id)
	 {
		Bill b= dao.searchBybillNo(id);
		return b;
	 }
	 
	 @GetMapping("/searchbybillno/{consumer_Employee_No}")
	 public User searchByUserNo(@PathVariable ("consumer_Employee_No") Integer consumer_Employee_No)
	 {
		User b= dao.searchByUserNo(consumer_Employee_No);
		return b;
	 }
}
