package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.ICustomerDao;
import com.app.pojos.Address;
import com.app.pojos.Bankdeatils;
import com.app.pojos.Bill;
import com.app.pojos.User;



@CrossOrigin
@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private ICustomerDao dao1;
	
	public CustomerController() 
	{
		
	}
	@GetMapping("/mybills/{id}")
	public List<Bill> allBills(@PathVariable("id") Integer id)
	{
		return dao1.allBills(id);	
	}
	@GetMapping("/mypendingbills/{id}")
	public List<Bill> myPendingaBills(@PathVariable("id") Integer id)
	{
		return dao1.myPendingaBills(id);	
	}
	@GetMapping("/mypaidbills/{id}")
	public List<Bill> myPaidbills(@PathVariable("id") Integer id)
	{
		return dao1.myPaidBills(id);	
	}
	
	@PostMapping("/forgetpassword")
	
	public User forGetPassword(@RequestBody User u)
	{
		User un =dao1.forGetPassword(u);
		return un;
		
	}
	//========================================================
	
	@PostMapping("/addbankdetails/{id}")
	public User addbankdetails(@RequestBody Bankdeatils b,@PathVariable("id") Integer id)
	{
		
		User u=dao1.addbankdetails(b,id);
		return u;
		
	}
	
	@PostMapping("/addAddress/{id}")
	public User addAddress(@RequestBody Address a,@PathVariable("id") Integer id)
	{
		
		User u=dao1.addAddress(a,id);
		return u;
		
	}
	
	@GetMapping("/paybill/{id}")
	public Bill paybill(@PathVariable("id") Integer id)
	{
		Bill bm=dao1.paybill(id);
		return bm;
		
	}
	@GetMapping("/myprofile/{id}")
	public User myProfile(@PathVariable("id") Integer id)
	{
		return dao1.myProfile(id);
	}
	@GetMapping("/searchbill/{id}")
	public Bill searchBill(@PathVariable("id") Integer id)
	{
		return dao1.searchBill(id);
	}
	
}
